
/*
E-Commerce Portal (Single-file React App)
This file is the main App component for the demo portal.
Note: This is a front-end demo — no backend or secure auth.
*/
import React, { useEffect, useState } from 'react'

// -------------------- Helper utilities --------------------
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

function saveToStorage(key, value) {
  localStorage.setItem(key, JSON.stringify(value))
}
function loadFromStorage(key, fallback) {
  const raw = localStorage.getItem(key)
  if (!raw) return fallback
  try { return JSON.parse(raw) } catch { return fallback }
}

// -------------------- Mock data --------------------
const SAMPLE_PRODUCTS = [
  { id: 'p1', name: 'Wireless Headphones', price: 79.99, rating: 4.5, description: 'Over-ear, noise-cancelling.' },
  { id: 'p2', name: 'Smartphone X', price: 699.0, rating: 4.7, description: '6.5-inch OLED display, 128GB.' },
  { id: 'p3', name: 'Mechanical Keyboard', price: 119.5, rating: 4.6, description: 'RGB, hot-swappable switches.' },
  { id: 'p4', name: 'Fitness Tracker', price: 49.99, rating: 4.1, description: 'Heart-rate, sleep tracking.' },
]

const SAMPLE_ORDERS = [
  { id: 'o1', items: ['Wireless Headphones'], total: 79.99, status: 'Delivered', date: '2025-10-20' },
  { id: 'o2', items: ['Mechanical Keyboard','Fitness Tracker'], total: 169.49, status: 'Shipped', date: '2025-11-04' },
]

// -------------------- App Component --------------------
export default function App() {
  // Authentication
  const [users, setUsers] = useState(() => loadFromStorage('ec_users', []))
  const [session, setSession] = useState(() => loadFromStorage('ec_session', null))

  // UI state
  const [tab, setTab] = useState('home') // home, products, contact, about, account

  // Products, wishlist, orders, reviews
  const [products] = useState(() => loadFromStorage('ec_products', SAMPLE_PRODUCTS))
  const [wishlist, setWishlist] = useState(() => loadFromStorage('ec_wishlist', []))
  const [orders, setOrders] = useState(() => loadFromStorage('ec_orders', SAMPLE_ORDERS))
  const [reviews, setReviews] = useState(() => loadFromStorage('ec_reviews', {})) // productId -> [{user, rating, text}]

  // Customer care reports
  const [reports, setReports] = useState(() => loadFromStorage('ec_reports', []))

  useEffect(() => saveToStorage('ec_users', users), [users])
  useEffect(() => saveToStorage('ec_session', session), [session])
  useEffect(() => saveToStorage('ec_wishlist', wishlist), [wishlist])
  useEffect(() => saveToStorage('ec_orders', orders), [orders])
  useEffect(() => saveToStorage('ec_reviews', reviews), [reviews])
  useEffect(() => saveToStorage('ec_reports', reports), [reports])

  // ---------------- Auth forms ----------------
  const [regForm, setRegForm] = useState({ name: '', email: '', password: '', confirm: '' })
  const [regErrors, setRegErrors] = useState({})

  const [loginForm, setLoginForm] = useState({ email: '', password: '' })
  const [loginError, setLoginError] = useState(null)

  function validateRegistration(form) {
    const errors = {}
    if (!form.name.trim()) errors.name = 'Full name is required.'
    if (!EMAIL_RE.test(form.email)) errors.email = 'Enter a valid email address.'
    if (form.password.length < 8) errors.password = 'Password must be at least 8 characters.'
    if (!/[A-Z]/.test(form.password)) errors.password = (errors.password ? errors.password + ' ' : '') + 'Include at least one uppercase letter.'
    if (!/[0-9]/.test(form.password)) errors.password = (errors.password ? errors.password + ' ' : '') + 'Include at least one digit.'
    if (form.password !== form.confirm) errors.confirm = 'Passwords do not match.'
    // Duplicate email check
    if (users.some(u => u.email.toLowerCase() === form.email.toLowerCase())) errors.email = 'Email already registered.'
    return errors
  }

  function handleRegister(e) {
    e.preventDefault()
    const errors = validateRegistration(regForm)
    setRegErrors(errors)
    if (Object.keys(errors).length > 0) return

    const newUser = { id: 'u' + Date.now(), name: regForm.name.trim(), email: regForm.email.toLowerCase(), password: regForm.password }
    const next = [...users, newUser]
    setUsers(next)
    setSession({ userId: newUser.id, name: newUser.name, email: newUser.email })
    setRegForm({ name: '', email: '', password: '', confirm: '' })
    setTab('home')
  }

  function handleLogin(e) {
    e.preventDefault()
    setLoginError(null)
    const found = users.find(u => u.email.toLowerCase() === loginForm.email.toLowerCase() && u.password === loginForm.password)
    if (!found) {
      setLoginError('Invalid email or password.')
      return
    }
    setSession({ userId: found.id, name: found.name, email: found.email })
    setLoginForm({ email: '', password: '' })
    setTab('home')
  }

  function handleLogout() {
    setSession(null)
  }

  // ---------------- Products / Wishlist / Orders / Reviews ----------------
  function toggleWishlist(productId) {
    if (!session) { alert('Please login to use wishlist.') ; return }
    const exists = wishlist.includes(productId)
    const next = exists ? wishlist.filter(id => id !== productId) : [...wishlist, productId]
    setWishlist(next)
  }

  function placeOrderFromCart(items) {
    if (!session) { alert('Login to place orders.'); return }
    const order = { id: 'o' + Date.now(), items: items.map(id => products.find(p => p.id === id).name), total: items.reduce((s,id) => s + (products.find(p=>p.id===id).price||0), 0), status: 'Processing', date: new Date().toISOString().slice(0,10) }
    setOrders([order, ...orders])
    // clear wishlist items placed
    setWishlist(prev => prev.filter(id => !items.includes(id)))
    alert('Order placed successfully!')
  }

  function addReview(productId, rating, text) {
    if (!session) { alert('Login to leave reviews.'); return }
    const itemReviews = reviews[productId] || []
    const newRev = { id: 'r' + Date.now(), user: session.name, rating, text, date: new Date().toISOString().slice(0,10) }
    setReviews({ ...reviews, [productId]: [newRev, ...itemReviews] })
  }

  // ---------------- Customer care / Reporting ----------------
  const [careForm, setCareForm] = useState({ subject: '', message: '', contact: '' })
  const [careErrors, setCareErrors] = useState({})

  function validateCare(form) {
    const e = {}
    if (!form.subject.trim()) e.subject = 'Subject required'
    if (!form.message.trim() || form.message.trim().length < 10) e.message = 'Message must be at least 10 characters.'
    if (form.contact && !EMAIL_RE.test(form.contact) && !/^\+?[0-9]{7,15}$/.test(form.contact)) e.contact = 'Provide a valid email or phone number.'
    return e
  }

  function submitCare(e) {
    e.preventDefault()
    const errors = validateCare(careForm)
    setCareErrors(errors)
    if (Object.keys(errors).length > 0) return
    const report = { id: 'rep' + Date.now(), user: session ? session.email : 'anonymous', ...careForm, date: new Date().toISOString().slice(0,10) }
    setReports([report, ...reports])
    setCareForm({ subject: '', message: '', contact: '' })
    alert('Customer care request submitted. We will respond via your contact method.')
  }

  // ---------------- Simple Reporting Options ----------------
  function exportData() {
    const payload = { users, orders, wishlist, reviews, reports }
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'ec_portal_export.json'
    a.click()
    URL.revokeObjectURL(url)
  }

  // ---------------- UI pieces ----------------
  function TopNav() {
    return (
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center text-xl font-bold">MyStore</div>
              <nav className="ml-8 flex space-x-4 items-center">
                <button onClick={() => setTab('home')} className={"px-3 py-2 rounded-md text-sm font-medium " + (tab==='home' ? 'bg-gray-100' : '')}>Home</button>
                <button onClick={() => setTab('products')} className={"px-3 py-2 rounded-md text-sm font-medium " + (tab==='products' ? 'bg-gray-100' : '')}>Products</button>
                <button onClick={() => setTab('contact')} className={"px-3 py-2 rounded-md text-sm font-medium " + (tab==='contact' ? 'bg-gray-100' : '')}>Contact Us</button>
                <button onClick={() => setTab('about')} className={"px-3 py-2 rounded-md text-sm font-medium " + (tab==='about' ? 'bg-gray-100' : '')}>About Us</button>
              </nav>
            </div>
            <div className="flex items-center">
              {session ? (
                <div className="flex items-center space-x-4">
                  <div className="text-sm">Hi, <strong>{session.name}</strong></div>
                  <button onClick={() => setTab('account')} className="px-3 py-1 border rounded">Account</button>
                  <button onClick={handleLogout} className="px-3 py-1 bg-red-500 text-white rounded">Logout</button>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <button onClick={() => setTab('login')} className="px-3 py-1 border rounded">Login</button>
                  <button onClick={() => setTab('register')} className="px-3 py-1 bg-blue-600 text-white rounded">Register</button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>
    )
  }

  function Home() {
    return (
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-4">Welcome to MyStore</h2>
        <p className="mb-4">This demo portal shows navigation, registration/login validation, wishlist, orders, reviews, customer care and reporting options. Use the Products tab to interact with items.</p>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {products.slice(0,3).map(p => (
            <div key={p.id} className="border rounded p-4">
              <h3 className="font-semibold">{p.name}</h3>
              <p className="text-sm text-gray-600">{p.description}</p>
              <div className="mt-2 flex items-center justify-between">
                <div className="text-lg font-bold">${p.price.toFixed(2)}</div>
                <button onClick={() => { toggleWishlist(p.id) }} className="px-2 py-1 border rounded">{wishlist.includes(p.id) ? 'Remove Wishlist' : 'Add Wishlist'}</button>
              </div>
            </div>
          ))}
        </section>
      </div>
    )
  }

  function Products() {
    const [selected, setSelected] = useState(null)
    const [reviewForm, setReviewForm] = useState({ rating: 5, text: '' })
    return (
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-4">Products</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {products.map(p => (
            <div key={p.id} className="border rounded p-4">
              <h3 className="font-semibold">{p.name}</h3>
              <p className="text-sm text-gray-600">{p.description}</p>
              <div className="mt-2 flex items-center justify-between">
                <div className="text-lg font-bold">${p.price.toFixed(2)}</div>
                <div className="space-x-2">
                  <button onClick={() => toggleWishlist(p.id)} className="px-2 py-1 border rounded">{wishlist.includes(p.id) ? '♥' : '♡'}</button>
                  <button onClick={() => setSelected(p)} className="px-2 py-1 bg-blue-600 text-white rounded">Details</button>
                </div>
              </div>
              <div className="mt-3 text-sm text-gray-700">Rating: {p.rating} ⭐</div>
            </div>
          ))}
        </div>

        {selected && (
          <div className="mt-6 border rounded p-4">
            <h3 className="text-xl font-bold">{selected.name}</h3>
            <p className="text-sm text-gray-600">{selected.description}</p>
            <div className="mt-3">Price: <strong>${selected.price.toFixed(2)}</strong></div>
            <div className="mt-3">Reviews:</div>
            <div className="mt-2">
              {(reviews[selected.id] || []).map(r => (
                <div key={r.id} className="border rounded p-2 mb-2">
                  <div className="text-sm font-medium">{r.user} — {r.rating} ⭐</div>
                  <div className="text-sm">{r.text}</div>
                  <div className="text-xs text-gray-500">{r.date}</div>
                </div>
              ))}
            </div>

            <div className="mt-4">
              <h4 className="font-semibold">Leave a review</h4>
              <div className="flex items-center space-x-2 mt-2">
                <label>Rating</label>
                <select value={reviewForm.rating} onChange={e => setReviewForm(s => ({ ...s, rating: Number(e.target.value) }))} className="border px-2 py-1 rounded">
                  <option value={5}>5</option>
                  <option value={4}>4</option>
                  <option value={3}>3</option>
                  <option value={2}>2</option>
                  <option value={1}>1</option>
                </select>
              </div>
              <textarea value={reviewForm.text} onChange={e => setReviewForm(s => ({ ...s, text: e.target.value }))} className="w-full border rounded p-2 mt-2" rows={3} placeholder="Your thoughts..."></textarea>
              <div className="mt-2 flex space-x-2">
                <button onClick={() => { addReview(selected.id, reviewForm.rating, reviewForm.text); setReviewForm({ rating:5, text:'' }) }} className="px-3 py-1 bg-green-600 text-white rounded">Submit</button>
                <button onClick={() => placeOrderFromCart([selected.id])} className="px-3 py-1 bg-indigo-600 text-white rounded">Buy Now</button>
              </div>
            </div>
          </div>
        )}

      </div>
    )
  }

  function Contact() {
    return (
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-4">Contact Us / Customer Care</h2>
        <div className="md:grid md:grid-cols-2 gap-6">
          <div>
            <p>If you have questions, concerns, or want to report an issue, use the customer care form. We validate subject, message length, and contact format.</p>
            <form onSubmit={submitCare} className="mt-4 space-y-3">
              <div>
                <label className="block text-sm">Subject</label>
                <input value={careForm.subject} onChange={e => setCareForm(s=>({...s,subject:e.target.value}))} className="w-full border rounded p-2" />
                {careErrors.subject && <div className="text-red-600 text-sm">{careErrors.subject}</div>}
              </div>
              <div>
                <label className="block text-sm">Message</label>
                <textarea value={careForm.message} onChange={e => setCareForm(s=>({...s,message:e.target.value}))} className="w-full border rounded p-2" rows={5}></textarea>
                {careErrors.message && <div className="text-red-600 text-sm">{careErrors.message}</div>}
              </div>
              <div>
                <label className="block text-sm">Contact (email or phone, optional)</label>
                <input value={careForm.contact} onChange={e => setCareForm(s=>({...s,contact:e.target.value}))} className="w-full border rounded p-2" />
                {careErrors.contact && <div className="text-red-600 text-sm">{careErrors.contact}</div>}
              </div>
              <div>
                <button className="px-4 py-2 bg-blue-600 text-white rounded">Submit</button>
              </div>
            </form>
          </div>
          <div>
            <h4 className="font-semibold">Previous Reports</h4>
            <div className="mt-2">
              {reports.length === 0 ? <div className="text-sm text-gray-600">No reports yet.</div> : reports.map(r => (
                <div key={r.id} className="border rounded p-2 mb-2">
                  <div className="text-sm font-medium">{r.subject} — by {r.user}</div>
                  <div className="text-xs text-gray-500">{r.date}</div>
                  <div className="text-sm">{r.message}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    )
  }

  function About() {
    return (
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-4">About Us</h2>
        <p>This demo site was built to show a minimal e-commerce portal. It focuses on front-end validation, user flows, and basic client-side storage. It is not production-ready (no backend, password hashing, or secure auth).</p>
      </div>
    )
  }

  function Account() {
    return (
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-4">Account Dashboard</h2>
        {!session ? (
          <div>Please login to access your account.</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold">Orders</h3>
              {orders.length===0 ? <div className="text-sm text-gray-600">No orders yet.</div> : orders.map(o=> (
                <div key={o.id} className="border rounded p-2 mb-2">
                  <div className="text-sm font-medium">Order {o.id} — ${o.total.toFixed(2)}</div>
                  <div className="text-xs text-gray-500">{o.date} — {o.status}</div>
                  <div className="text-sm">Items: {o.items.join(', ')}</div>
                </div>
              ))}
            </div>

            <div>
              <h3 className="font-semibold">Wishlist</h3>
              {wishlist.length===0 ? <div className="text-sm text-gray-600">Wishlist empty.</div> : wishlist.map(id => {
                const p = products.find(pp => pp.id === id)
                return (
                  <div key={id} className="border rounded p-2 mb-2 flex justify-between items-center">
                    <div>
                      <div className="font-medium">{p.name}</div>
                      <div className="text-xs text-gray-500">${p.price.toFixed(2)}</div>
                    </div>
                    <div className="space-x-2">
                      <button onClick={() => placeOrderFromCart([id])} className="px-2 py-1 bg-indigo-600 text-white rounded">Buy</button>
                      <button onClick={() => toggleWishlist(id)} className="px-2 py-1 border rounded">Remove</button>
                    </div>
                  </div>
                )
              })}

              <div className="mt-4">
                <h4 className="font-semibold">Reporting Tools</h4>
                <p className="text-sm text-gray-700">Export your data or clear demo data.</p>
                <div className="mt-2 flex space-x-2">
                  <button onClick={exportData} className="px-3 py-1 bg-gray-800 text-white rounded">Export JSON</button>
                  <button onClick={() => { if (confirm('Clear demo data (localStorage)?')) { localStorage.clear(); location.reload() } }} className="px-3 py-1 bg-red-500 text-white rounded">Clear Demo Data</button>
                </div>
              </div>

            </div>
          </div>
        )}
      </div>
    )
  }

  function LoginRegisterArea() {
    if (tab === 'register') {
      return (
        <div className="p-6 max-w-md mx-auto">
          <h2 className="text-2xl font-bold mb-4">Register</h2>
          <form onSubmit={handleRegister} className="space-y-3">
            <div>
              <label className="block text-sm">Full name</label>
              <input value={regForm.name} onChange={e=>setRegForm(s=>({...s,name:e.target.value}))} className="w-full border rounded p-2" />
              {regErrors.name && <div className="text-red-600 text-sm">{regErrors.name}</div>}
            </div>
            <div>
              <label className="block text-sm">Email</label>
              <input value={regForm.email} onChange={e=>setRegForm(s=>({...s,email:e.target.value}))} className="w-full border rounded p-2" />
              {regErrors.email && <div className="text-red-600 text-sm">{regErrors.email}</div>}
            </div>
            <div>
              <label className="block text-sm">Password</label>
              <input type="password" value={regForm.password} onChange={e=>setRegForm(s=>({...s,password:e.target.value}))} className="w-full border rounded p-2" />
              {regErrors.password && <div className="text-red-600 text-sm">{regErrors.password}</div>}
            </div>
            <div>
              <label className="block text-sm">Confirm Password</label>
              <input type="password" value={regForm.confirm} onChange={e=>setRegForm(s=>({...s,confirm:e.target.value}))} className="w-full border rounded p-2" />
              {regErrors.confirm && <div className="text-red-600 text-sm">{regErrors.confirm}</div>}
            </div>
            <div>
              <button className="px-4 py-2 bg-green-600 text-white rounded">Create Account</button>
            </div>
          </form>
        </div>
      )
    }
    if (tab === 'login') {
      return (
        <div className="p-6 max-w-md mx-auto">
          <h2 className="text-2xl font-bold mb-4">Login</h2>
          <form onSubmit={handleLogin} className="space-y-3">
            <div>
              <label className="block text-sm">Email</label>
              <input value={loginForm.email} onChange={e=>setLoginForm(s=>({...s,email:e.target.value}))} className="w-full border rounded p-2" />
            </div>
            <div>
              <label className="block text-sm">Password</label>
              <input type="password" value={loginForm.password} onChange={e=>setLoginForm(s=>({...s,password:e.target.value}))} className="w-full border rounded p-2" />
            </div>
            {loginError && <div className="text-red-600">{loginError}</div>}
            <div>
              <button className="px-4 py-2 bg-blue-600 text-white rounded">Login</button>
            </div>
          </form>
        </div>
      )
    }
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <TopNav />
      <main className="max-w-7xl mx-auto p-4">
        {tab === 'home' && <Home />}
        {tab === 'products' && <Products />}
        {tab === 'contact' && <Contact />}
        {tab === 'about' && <About />}
        {tab === 'account' && <Account />}
        {(tab === 'login' || tab === 'register') && <LoginRegisterArea />}

        <footer className="mt-12 p-4 text-center text-xs text-gray-500">Demo E-Commerce Portal — not for production. Data is stored in browser localStorage.</footer>
      </main>
    </div>
  )
}
