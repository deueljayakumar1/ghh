# Demo E-Commerce Portal

This is a small demo React + Vite project that implements:
- Navigation (Home, Products, Contact Us, About Us)
- Registration & Login with client-side validation
- Orders, Wishlist, Reviews
- Customer Care form and reporting/export tools
- Local persistence using localStorage

Quick start:
1. Install dependencies: `npm install`
2. Start dev server: `npm run dev`
3. Open the URL shown by Vite (usually http://localhost:5173)

Tailwind is included in devDependencies. If you want full Tailwind setup, see the comments in this repository or follow Tailwind + Vite docs.
